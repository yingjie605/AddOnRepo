#!/usr/bin/python
# -*- coding: utf-8 -*-
##┌──────────────────────────────────────
##│  Tv-Icon.jp v0.0.1 (2014/06/24)
##│  Copyright (c) Inpane
##│  script.tv-icon.jp
##│  http://xbmc.inpane.com/
##│  info@inpane.com
##└──────────────────────────────────────
##
## [ 更新履歴 ]
## 2014/06/24 -> v0.0.1
##  テスト版公開
##
##==============================================================================
## 設定値をここに記載する。
import sys, os, string

__script_path__  = os.path.abspath( os.path.dirname(__file__) )
__data_path__    = os.path.abspath( __script_path__ + '/data' )
__zip_url__      = 'http://www.team-mediaportal.com/index.php?option=com_mtree&task=att_download&link_id=318&cf_id=24'
__msg_download__ = 'チャンネルアイコンをダウンロード中･･･'
__msg_complete__ = 'チャンネルアイコン取得完了。XBMCを再起動してください。'

#-------------------------------------------------------------------------------
import re
import httplib, urllib, urllib2, cookielib
import struct, zlib, xml.dom.minidom
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
import zipfile, unicodedata, cgi

#-------------------------------------------------------------------------------
__addon_id__ = 'script.tv-icon.jp'
__settings__ = xbmcaddon.Addon(__addon_id__)

try:    __xbmc_version__ = xbmc.getInfoLabel('System.BuildVersion')
except: __xbmc_version__ = 'Unknown'
class AppURLopener(urllib.FancyURLopener):
	version = 'XBMC/' + __xbmc_version__ + ' - Download and play (' + os.name + ')'
urllib._urlopener = AppURLopener()

IN  = {}
OUT = {}

#-------------------------------------------------------------------------------
def getParams():
	ParamDict = {}
	try:
		#print "getParams() argv=", sys.argv
		if sys.argv[2] : ParamPairs = sys.argv[2][1:].split( "&" )
		for ParamsPair in ParamPairs : 
			ParamSplits = ParamsPair.split('=')
			if (len(ParamSplits)) == 2 : ParamDict[ParamSplits[0]] = ParamSplits[1]
	except : pass
	return ParamDict

#-------------------------------------------------------------------------------
def main():

	global IN
	global OUT
	IN = getParams()

	try:
		response = urllib2.urlopen(__zip_url__)
		_,params = cgi.parse_header(response.headers.get('Content-Disposition'))
		zippath = __data_path__ + "/" + params['filename']
		dialog = xbmcgui.DialogProgress()
		dialog.create(__addon_id__, __msg_download__)
		TotalSize = response.info().getheader('Content-Length').strip()
		TotalSize = int(TotalSize)
		NowSize = 0
		ChunkSize = 8192

		f = open(zippath, 'wb')
		while 1:
			chunk = response.read(ChunkSize)
			NowSize += len(chunk)
			f.write(chunk)
			dialog.update(100*NowSize/TotalSize, __msg_download__)
			if not chunk: break
		f.close()
		dialog.close()

	except:
		return 1

	#zippath = __data_path__ + "/JP TV Logos v.1.0.0.zip"
	JsonDataPath = os.path.abspath(__data_path__ + "/a").rstrip('a').replace('\\', '\\\\')
	xbmc.executeJSONRPC('{"jsonrpc":"2.0", "method":"Settings.SetSettingValue", "params":{"setting":"pvrmenu.iconpath","value":"' + JsonDataPath + '"}, "id":1}')

	zf = zipfile.ZipFile(zippath, mode='r')
	for name in zf.namelist():
		data   = zf.read(name)
		name_s = name.decode("cp932")
		fpath = __data_path__ + "/" + name_s
		ofh = open(fpath,"wb")
		ofh.write(data)
		ofh.close()
	zf.close()

	dialog = xbmcgui.Dialog()
	ok = dialog.ok(__addon_id__, __msg_complete__)

#-------------------------------------------------------------------------------
if __name__  == '__main__': main()
